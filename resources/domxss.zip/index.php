<!DOCTYPE html>
<html>
<body>
<div>
	<h1>XSS Basé sur le DOM</h1>
 
 		<p>Veuillez sélectionner une langue :</p>

		<form name="XSS" method="GET">
			<select name="defaut">
				<script>
					if (document.location.href.indexOf("defaut=") >= 0) {
						var langue = document.location.href.substring(document.location.href.indexOf("defaut=")+7);
						document.write("<option value='" + langue + "'>" + decodeURI(langue) + "</option>");
						document.write("<option value='-' disabled='disabled'>----</option>");
					}
					    
					document.write("<option value='Anglais'>Anglais</option>");
					document.write("<option value='Français'>Français</option>");
					document.write("<option value='Allemand'>Allemand</option>");
					document.write("<option value='Polonais'>Polonais</option>");
				</script>
			</select>
			<input type="submit" value="Changer" />
		</form>
	<hr><br>
	<script>
		switch(decodeURI(langue)) {
			case "Anglais": document.write("Hello.");
			break;
			case "Français": document.write("Bonjour.");
			break;
			case "Allemand": document.write("Guten Tag.");
			break;
			case "Polonais": document.write("Dzien Dobry.");
			break;
		}
	</script>
</div>
</body>
</html>
